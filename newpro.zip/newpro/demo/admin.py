from django.contrib import admin
from demo.models import*
# Register your models here.
admin.site.register(branch)
admin.site.register(state)
admin.site.register(district)