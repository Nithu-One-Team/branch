from django.db import models

# Create your models here.
class state(models.Model):
    states=models.CharField(max_length=500)
    def __str__(self):
        return self.states
class district(models.Model):
    dist=models.CharField(max_length=500)
    def __str__(self):
        return self.dist
class branch(models.Model):
    brranch=models.CharField(max_length=500)
    Address=models.TextField(max_length=500)
    street=models.CharField(max_length=500)
    State=models.ForeignKey("state", on_delete=models.CASCADE)
    District=models.ForeignKey("district", on_delete=models.CASCADE)
    pincode=models.IntegerField()
    mobile=models.CharField(max_length=500)
    email=models.CharField(max_length=500)
