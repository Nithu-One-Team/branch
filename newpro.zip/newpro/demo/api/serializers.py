from rest_framework import serializers
from demo.models import*

class branchserializer(serializers.Serializer):
    id=serializers.IntegerField(read_only=True)
    brranch=serializers.CharField()
    Address=serializers.CharField()
    street=serializers.CharField()
    State=serializers.CharField()
    District=serializers.CharField()
    pincode=serializers.CharField()
    mobile=serializers.CharField()
    email=serializers.CharField()
    def create(self,validated_data):
        return branch.objects.create(**validated_data)
    def update(self,instance,validated_data): 
    # instance carry old values,validated_data carry new values
        instance.brranch=validated_data.get('brranch',instance.brranch)
        instance.Address=validated_data.get('Address',instance.Address)
        instance.street=validated_data.get('street',instance.street)
        instance.State=validated_data.get('State',instance.State)
        instance.District=validated_data.get('District',instance.District)
        instance.pincode=validated_data.get('pincode',instance.pincode)
        instance.mobile=validated_data.get('mobile',instance.mobile)
        instance.email=validated_data.get('email',instance.email)





        

        

        instance.save()
        return instance

