from django.urls import path
from demo.api.views import*

urlpatterns =[
    path('branchh',branchh,name="branchh"),
]